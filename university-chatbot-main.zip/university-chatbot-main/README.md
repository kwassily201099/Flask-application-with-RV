#University Chat-Bot with RiveScript

Prerequisite

1. Clone this repo with git clone < github link >
2. Open a command line and type: python3 -m venv env to create a virtual env
3. Activate virtual env with source env/bin/activate. For windows please 
you can find documentation here: https://docs.python.org/3/library/venv.html
4. Go inside the Chat-Bot directory.
5. Run pip3 install -r requirements.txt


How to run.

1. Inside of Chat-Bot dir type in terminal/console python3 bot.py.
2. Click on link from the output.
3. Hit run button to give instruction to the bot.
4. If you want another type of conversation you can paste/create
some Rivescript code and paste in left side on ui. 
