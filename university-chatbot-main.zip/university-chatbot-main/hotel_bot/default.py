
DEFAULT_SOURCE = """
+ hello
- hello
+ my name is *
- <set name=<formal>>Nice to meet you, <get name>.
+ can you tell me please if you have the books available
- sure
- we have available 20 books
+ can i borrow one
- yes
+ *
- I don't have a reply for that.
- Try asking that a different way."""